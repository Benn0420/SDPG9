**********************************
* README File for Solitaire Game *
**********************************


Game Overview:

Welcome to SDPG9's Solitaire Game, a classic Solitaire game with a twist! The objective of the game is to arrange cards in descending order and alternating colors to build up each of the four foundation piles in the upper right corner, starting with the aces. Explore various game modes and challenges as you sharpen your card-playing skills.


Installation Instructions:

Download the zip file: containing "cardgame.exe" & "_internal" from the provided link.
Extract all from the zip file to a suitable location.
Double-click the executable file to launch the game.
Navigate the main menu to the instructions view prior to starting.
Choose between Normal or Vegas mode to begin playing.


Game Controls:

Mouse: Click, drag, & drop cards to move them.


Software Requirements:

Operating System: Windows 10 or later
Python Version: Python 3.7 or higher
Arcade Library: Version 2.5.7 or higher


Hardware Requirements:

Processor: Intel Core i3 or equivalent
RAM: 4GB or more
Graphics: Integrated graphics or dedicated GPU with OpenGL 3.3 support
Storage: 100MB free space


Troubleshooting:

Issue: Game crashes on startup.
Solution: Ensure that Python and the Arcade library are properly installed. Try running the game as an administrator.
Issue: Cards are not displaying correctly.
Solution: Update your graphics drivers and ensure that your GPU supports OpenGL 3.3 or higher.
For additional support, you can contact our technical team.


Credits:

Connor Bennett
Ashlynn Cook
Katelyn Biro
Minhthuy Bui
Yu Song


Libraries and Tools:

Python: python.org
Arcade Library: arcade.academy